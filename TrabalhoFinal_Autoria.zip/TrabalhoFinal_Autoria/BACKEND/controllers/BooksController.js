const express = require('express');
const router = express.Router();  
const db = require('../util/db');
const verificarToken = require('../util/VerificaToken');

/**
 * Executa uma consulta no banco de dados e envia uma resposta.
 * @param {string} sql - A consulta SQL a ser executada.
 * @param {Array} params - Os parâmetros para a consulta SQL.
 * @param {Object} res - O objeto de resposta do Express.
 * @param {string} erroMsg - Mensagem de erro para ser enviada em caso de falha.
 */
function executarComandoSQL(sql, params, res, erroMsg) {
  db.query(sql, params, (err, result) => {
    if (err) {
      res.status(500).json({ erro: erroMsg, detalhes: err });
    } else {
      res.status(200).json(result);
    }
  });
}

// Rota para buscar todas as bookss
router.get('/', (req, res) => {
 executarComandoSQL('SELECT * FROM books', [], res, "Erro na consulta de bookss");
});

// Rota para buscar uma books específica
router.get("/:id", (req, res) => {
  const id = req.params.id;
 executarComandoSQL('SELECT * FROM books WHERE id_book = ?', [id], res, "Erro na consulta de books");
});

// Rota para criar uma nova books
router.post('/', (req, res) => {
  const { nome_book, escritor_book, editora_book } = req.body;
 executarComandoSQL('INSERT INTO books (nome_book, escritor_book, editora_book) VALUES (?, ?, ?)', [nome_book, escritor_book, editora_book], res, "Erro no cadastro de books!");
});

// Rota para deletar uma books
router.delete("/:id", (req, res) => {
  const booksId = req.params.id;
 executarComandoSQL('DELETE FROM books WHERE id_book = ?', [booksId], res, 'Erro ao deletar books');
});

// Rota para atualizar uma books
router.put('/', (req, res) => {
  const { id_book, nome_book, escritor_book, editora_book } = req.body;
 executarComandoSQL('UPDATE books SET nome_book = ?, escritor_book = ?, editora_book = ? WHERE id_book = ?', [nome_book, escritor_book, editora_book ,id_book], res, "Erro ao atualizar books");
});

module.exports = router;