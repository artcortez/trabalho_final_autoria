const express = require('express');
const router = express.Router();  
const db = require('../util/db');
const verificarToken = require('../util/VerificaToken');

/**
 * Executa uma consulta no banco de dados e envia uma resposta.
 * @param {string} sql - A consulta SQL a ser executada.
 * @param {Array} params - Os parâmetros para a consulta SQL.
 * @param {Object} res - O objeto de resposta do Express.
 * @param {string} erroMsg - Mensagem de erro para ser enviada em caso de falha.
 */
function executarComandoSQL(sql, params, res, erroMsg) {
  db.query(sql, params, (err, result) => {
    if (err) {
      res.status(500).json({ erro: erroMsg, detalhes: err });
    } else {
      res.status(200).json(result);
    }
  });
}

// Rota para buscar todas as autoress
router.get('/', (req, res) => {
 executarComandoSQL('SELECT * FROM autores', [], res, "Erro na consulta de autoress");
});

// Rota para buscar uma autores específica
router.get("/:id", (req, res) => {
  const id = req.params.id;
 executarComandoSQL('SELECT * FROM autores WHERE id_autor = ?', [id], res, "Erro na consulta de autores");
});

// Rota para criar uma nova autores
router.post('/', (req, res) => {
  const { nome_autor, data_nascimento } = req.body;
 executarComandoSQL('INSERT INTO autores (nome_autor, data_nascimento) VALUES (?, ?)', [nome_autor, data_nascimento], res, "Erro no cadastro de autores!");
});

// Rota para deletar uma autores
router.delete("/:id", (req, res) => {
  const autoresId = req.params.id;
 executarComandoSQL('DELETE FROM autores WHERE id_autor = ?', [autoresId], res, 'Erro ao deletar autores');
});

// Rota para atualizar uma autores
router.put('/', (req, res) => {
  const { id_autor, nome_autor, data_nascimento } = req.body;
 executarComandoSQL('UPDATE autores SET nome_autor = ?, data_nascimento = ? WHERE id_autor = ?', [nome_autor, data_nascimento, id_autor], res, "Erro ao atualizar autores");
});

module.exports = router;