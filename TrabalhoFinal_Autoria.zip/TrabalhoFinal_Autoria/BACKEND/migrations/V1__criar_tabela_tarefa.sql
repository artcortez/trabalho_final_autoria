-- Criando a tabela de autores com a coluna data_nascimento
CREATE TABLE IF NOT EXISTS autores (
    id_autor INT PRIMARY KEY AUTO_INCREMENT,
    nome_autor VARCHAR(50) NOT NULL,
    data_nascimento DATE
);

-- Criando a tabela de editoras
CREATE TABLE IF NOT EXISTS editoras (
    id_editora INT PRIMARY KEY AUTO_INCREMENT,
    nome_editora VARCHAR(50) NOT NULL
);

--Criando a tabela de livros SEM CHAVES ESTRANGEIRAS PRA NAO DAR TRABALHO
CREATE TABLE IF NOT EXISTS books (
    id_book INT PRIMARY KEY AUTO_INCREMENT,
    nome_book VARCHAR(100) NOT NULL,
    escritor_book VARCHAR(100),
    editora_book VARCHAR(100)
);