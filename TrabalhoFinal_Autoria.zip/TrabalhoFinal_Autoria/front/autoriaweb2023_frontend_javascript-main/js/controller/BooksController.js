import BooksView from "../view/BooksView.js";
import { API_BASE_URL } from "../config/config.js";

/**
 * Renderiza o formulário de autores.
 * @param {HTMLElement} componentePrincipal - Elemento principal onde o formulário será renderizado.
 */
function renderizarBooksFormulario(componentePrincipal) {
  componentePrincipal.innerHTML = BooksView.renderizarFormulario();
  document.getElementById("formulario_books").addEventListener("submit", cadastrarBooks);
}

/** 
 * Cadastra um novo autor.
 * @param {Event} event - Evento do formulário.
 */
async function cadastrarBooks(event) {
  event.preventDefault();
  const nomeValor = document.getElementById("books_nome_book_formulario").value;
  const escritor_bookValor = document.getElementById("books_escritor_book_formulario").value;
  const editora_bookValor = document.getElementById("books_editora_book_formulario").value;
  const novaBooks = { nome_book: nomeValor, escritor_book: escritor_bookValor, editora_book: editora_bookValor };

  try {
    await fetch(`${API_BASE_URL}/books`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(novaBooks),
    });
    const componentePrincipal = document.querySelector("#conteudo_principal");
    await renderizarListaBooks(componentePrincipal);
  } catch (error) {
    console.error("Erro ao adicionar autor:", error);
  }
}
/**
 * Renderiza a lista de autores.
 * @param {HTMLElement} componentePrincipal - Elemento principal onde a lista será renderizada.
 */
async function renderizarListaBooks(componentePrincipal) {
  try {
    const response = await fetch(API_BASE_URL + "/books");
    const booksBD = await response.json();

    const books = booksBD.map((row) => {
      return {
        id_book: row.id_book,
        nome_book: row.nome_book,
        escritor_book: row.escritor_book,
        editora_book: row.editora_book,
      };
    });

    componentePrincipal.innerHTML = BooksView.renderizarTabela(books);
    inserirEventosExcluir();  // Chame a função para inserir eventos de exclusão
    inserirEventosAtualizar();
  } catch (error) {
    console.error("Erro ao buscar autores:", error);
  }
}

/**
 * Adiciona eventos de clique aos botões de exclusão de autores.
 * Cada botão, quando clicado, aciona a função de exclusão de autor correspondente.
 */
function inserirEventosExcluir() {
  const botoesExcluir = document.querySelectorAll(".excluir-btn");
  botoesExcluir.forEach((botao) => {
    botao.addEventListener("click", function () {
      const booksId = this.getAttribute("books-id_book");
      excluirBooks(booksId);
    });
  });
}

/**
 * Adiciona eventos de clique aos botões de atualização de autor.
 * Cada botão, quando clicado, aciona a função de buscar o autor específica para atualização.
 */
function inserirEventosAtualizar() {
  const botoesAtualizar = document.querySelectorAll(".atualizar-btn");
  botoesAtualizar.forEach((botao) => {
    botao.addEventListener("click", function () {
      const booksId = this.getAttribute("books-atualizar-id_book");
      buscarBooks(booksId);
    });
  });
}

/**
 * Exclui um autor específica com base no ID.
 * Após a exclusão bem-sucedida, a lista de autores é atualizada.
 * @param {string} id_book- ID de autor a ser excluída.
 */
async function excluirBooks(id_book) { 
  try {
    const response = await fetch(`${API_BASE_URL}/books/${id_book}`, { method: "DELETE" });
    if (!response.ok) throw new Error("Erro ao excluir o autor");
    const componentePrincipal = document.querySelector("#conteudo_principal");
    renderizarListaBooks(componentePrincipal);
  } catch (error) {
    console.error("Erro ao excluir o autor:", error);
  }
}

/**
 * Busca um autor específica para atualização, com base no ID.
 * Após encontrar o autor, renderiza o formulário de atualização.
 * @param {string} id_book - ID do autor a ser buscada.
 */
async function buscarBooks(id_book) {
  try {
    const response = await fetch(`${API_BASE_URL}/books/${id_book}`);
    const booksBD = await response.json();
    if (booksBD.length <= 0) return;

    const books = booksBD.map(row => ({
      id_book: row.id_book,
      nome_book: row.nome_book,
      escritor_book: row.escritor_book,
      editora_book: row.editora_book,
    }))[0];

    const componentePrincipal = document.querySelector("#conteudo_principal");
    componentePrincipal.innerHTML = BooksView.renderizarFormularioAtualizar(books);
    document.getElementById("formulario_books_atualizar").addEventListener("submit", atualizarBooks);
  } catch (error) {
    console.error("Erro ao buscar autores:", error);
  }
}

/**
 * Atualiza um autor específico.
 * A função é acionada pelo evento de submit do formulário de atualização.
 * @param {Event} event - O evento de submit do formulário.
 */
async function atualizarBooks(event) {
  event.preventDefault();

  const id_bookValor = document.getElementById("books_id_book_formulario").value;
  const nome_bookValor = document.getElementById("books_nome_book_formulario").value;
  const escritor_bookValor = document.getElementById("books_escritor_book_formulario").value;
  const editora_bookValor = document.getElementById("books_editora_book_formulario").value;
  const books = {id_book: id_bookValor, nome_book: nome_bookValor, escritor_book: escritor_bookValor, editora_book: editora_bookValor};

  try {
    const response = await fetch(`${API_BASE_URL}/books`, {
      method: "PUT",
      headers: {"Content-Type": "application/json",},
      body: JSON.stringify(books),
    });

    if (!response.ok) {
      throw new Error("Falha ao atualizar o autor");
    }
    const componentePrincipal = document.querySelector("#conteudo_principal");
    renderizarListaBooks(componentePrincipal);
  } catch (error) {
    console.error("Erro ao atualizar o autor:", error);
  }
}

const BooksController = {
  renderizarBooksFormulario,
  cadastrarBooks,
  renderizarListaBooks,
  excluirBooks,
};

export default BooksController;