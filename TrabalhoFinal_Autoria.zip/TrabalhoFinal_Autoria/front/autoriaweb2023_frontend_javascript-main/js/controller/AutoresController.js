import AutoresView from "../view/AutoresView.js";
import { API_BASE_URL } from "../config/config.js";

/**
 * Renderiza o formulário de autores.
 * @param {HTMLElement} componentePrincipal - Elemento principal onde o formulário será renderizado.
 */
function renderizarAutoresFormulario(componentePrincipal) {
  componentePrincipal.innerHTML = AutoresView.renderizarFormulario();
  document.getElementById("formulario_autores").addEventListener("submit", cadastrarAutores);
}

/** 
 * Cadastra um novo autor.
 * @param {Event} event - Evento do formulário.
 */
async function cadastrarAutores(event) {
  event.preventDefault();
  const nomeValor = document.getElementById("autores_nome_autor_formulario").value;
  const data_nascimentoValor = document.getElementById("autores_data_nascimento_formulario").value;
  const novaAutores = { nome_autor: nomeValor, data_nascimento: data_nascimentoValor };

  try {
    console.log("Enviando requisição de cadastro:", novaAutores); // Adicione este log
    await fetch(`${API_BASE_URL}/autores`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(novaAutores),
    });
    const componentePrincipal = document.querySelector("#conteudo_principal");
    await renderizarListaAutores(componentePrincipal);
  } catch (error) {
    console.error("Erro ao adicionar autor:", error);
  }
}
/**
 * Renderiza a lista de autores.
 * @param {HTMLElement} componentePrincipal - Elemento principal onde a lista será renderizada.
 */
async function renderizarListaAutores(componentePrincipal) {
  try {
    const response = await fetch(API_BASE_URL + "/autores");
    const autoresBD = await response.json();

    const autores = autoresBD.map((row) => {
      return {
        id_autor: row.id_autor,
        nome_autor: row.nome_autor,
        data_nascimento: row.data_nascimento,
      };
    });

    componentePrincipal.innerHTML = AutoresView.renderizarTabela(autores);
    inserirEventosExcluir();  // Chame a função para inserir eventos de exclusão
    inserirEventosAtualizar();
  } catch (error) {
    console.error("Erro ao buscar autores:", error);
  }
}

/**
 * Adiciona eventos de clique aos botões de exclusão de autores.
 * Cada botão, quando clicado, aciona a função de exclusão de autor correspondente.
 */
function inserirEventosExcluir() {
  const botoesExcluir = document.querySelectorAll(".excluir-btn");
  botoesExcluir.forEach((botao) => {
    botao.addEventListener("click", function () {
      const autoresId = this.getAttribute("autores-id_autor");
      excluirAutores(autoresId);
    });
  });
}

/**
 * Adiciona eventos de clique aos botões de atualização de autor.
 * Cada botão, quando clicado, aciona a função de buscar o autor específica para atualização.
 */
function inserirEventosAtualizar() {
  const botoesAtualizar = document.querySelectorAll(".atualizar-btn");
  botoesAtualizar.forEach((botao) => {
    botao.addEventListener("click", function () {
      const autoresId = this.getAttribute("autores-atualizar-id_autor");
      buscarAutores(autoresId);
    });
  });
}

/**
 * Exclui um autor específica com base no ID.
 * Após a exclusão bem-sucedida, a lista de autores é atualizada.
 * @param {string} id_autor - ID de autor a ser excluída.
 */
async function excluirAutores(id_autor) { 
  try {
    const response = await fetch(`${API_BASE_URL}/autores/${id_autor}`, { method: "DELETE" });
    if (!response.ok) throw new Error("Erro ao excluir o autor");
    const componentePrincipal = document.querySelector("#conteudo_principal");
    renderizarListaAutores(componentePrincipal);
  } catch (error) {
    console.error("Erro ao excluir o autor:", error);
  }
}

/**
 * Busca um autor específica para atualização, com base no ID.
 * Após encontrar o autor, renderiza o formulário de atualização.
 * @param {string} id_autor - ID do autor a ser buscada.
 */
async function buscarAutores(id_autor) {
  try {
    const response = await fetch(`${API_BASE_URL}/autores/${id_autor}`);
    const autoresBD = await response.json();
    if (autoresBD.length <= 0) return;

    const autores = autoresBD.map(row => ({
      id_autor: row.id_autor,
      nome_autor: row.nome_autor,
      data_nascimento: row.data_nascimento,
    }))[0];

    const componentePrincipal = document.querySelector("#conteudo_principal");
    componentePrincipal.innerHTML = AutoresView.renderizarFormularioAtualizar(autores);
    document.getElementById("formulario_autores_atualizar").addEventListener("submit", atualizarAutores);
  } catch (error) {
    console.error("Erro ao buscar autores:", error);
  }
}

/**
 * Atualiza um autor específico.
 * A função é acionada pelo evento de submit do formulário de atualização.
 * @param {Event} event - O evento de submit do formulário.
 */
async function atualizarAutores(event) {
  event.preventDefault();

  const id_autorValor = document.getElementById("autores_id_autor_formulario").value;
  const nome_autorValor = document.getElementById("autores_nome_autor_formulario").value;
  const data_nascimentoValor = document.getElementById("autores_data_nascimento_formulario").value;
  const autores = {id_autor: id_autorValor, nome_autor: nome_autorValor, data_nascimento: data_nascimentoValor,};

  try {
    const response = await fetch(`${API_BASE_URL}/autores`, {
      method: "PUT",
      headers: {"Content-Type": "application/json",},
      body: JSON.stringify(autores),
    });

    if (!response.ok) {
      throw new Error("Falha ao atualizar o autor");
    }
    const componentePrincipal = document.querySelector("#conteudo_principal");
    renderizarListaAutores(componentePrincipal);
  } catch (error) {
    console.error("Erro ao atualizar o autor:", error);
  }
}

const AutoresController = {
  renderizarAutoresFormulario,
  cadastrarAutores,
  renderizarListaAutores,
  excluirAutores,
};

export default AutoresController;