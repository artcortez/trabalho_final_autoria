import EditorasView from "../view/EditorasView.js";
import { API_BASE_URL } from "../config/config.js";

/**
 * Renderiza o formulário de autores.
 * @param {HTMLElement} componentePrincipal - Elemento principal onde o formulário será renderizado.
 */
function renderizarEditorasFormulario(componentePrincipal) {
  componentePrincipal.innerHTML = EditorasView.renderizarFormulario();
  document.getElementById("formulario_editoras").addEventListener("submit", cadastrarEditoras);
}

/** 
 * Cadastra um novo autor.
 * @param {Event} event - Evento do formulário.
 */
async function cadastrarEditoras(event) {
  event.preventDefault();
  const nomeValor = document.getElementById("editoras_nome_editora_formulario").value;
  const novaEditoras = { nome_editora: nomeValor };

  try {
    console.log("Enviando requisição de cadastro:", novaEditoras); // Adicione este log
    await fetch(`${API_BASE_URL}/editoras`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(novaEditoras),
    });
    const componentePrincipal = document.querySelector("#conteudo_principal");
    await renderizarListaEditoras(componentePrincipal);
  } catch (error) {
    console.error("Erro ao adicionar autor:", error);
  }
}
/**
 * Renderiza a lista de autores.
 * @param {HTMLElement} componentePrincipal - Elemento principal onde a lista será renderizada.
 */
async function renderizarListaEditoras(componentePrincipal) {
  try {
    const response = await fetch(API_BASE_URL + "/editoras");
    const editorasBD = await response.json();

    const editoras = editorasBD.map((row) => {
      return {
        id_editora: row.id_editora,
        nome_editora: row.nome_editora,
      };
    });

    componentePrincipal.innerHTML = EditorasView.renderizarTabela(editoras);
    inserirEventosExcluir();  // Chame a função para inserir eventos de exclusão
    inserirEventosAtualizar();
  } catch (error) {
    console.error("Erro ao buscar autores:", error);
  }
}

/**
 * Adiciona eventos de clique aos botões de exclusão de autores.
 * Cada botão, quando clicado, aciona a função de exclusão de autor correspondente.
 */
function inserirEventosExcluir() {
  const botoesExcluir = document.querySelectorAll(".excluir-btn");
  botoesExcluir.forEach((botao) => {
    botao.addEventListener("click", function () {
      const editorasId = this.getAttribute("editoras-id_editora");
      excluirEditoras(editorasId);
    });
  });
}

/**
 * Adiciona eventos de clique aos botões de atualização de autor.
 * Cada botão, quando clicado, aciona a função de buscar o autor específica para atualização.
 */
function inserirEventosAtualizar() {
  const botoesAtualizar = document.querySelectorAll(".atualizar-btn");
  botoesAtualizar.forEach((botao) => {
    botao.addEventListener("click", function () {
      const editorasId = this.getAttribute("editoras-atualizar-id_editora");
      buscarEditoras(editorasId);
    });
  });
}

/**
 * Exclui um autor específica com base no ID.
 * Após a exclusão bem-sucedida, a lista de autores é atualizada.
 * @param {string} id_editora - ID de autor a ser excluída.
 */
async function excluirEditoras(id_editora) { 
  try {
    const response = await fetch(`${API_BASE_URL}/editoras/${id_editora}`, { method: "DELETE" });
    if (!response.ok) throw new Error("Erro ao excluir o autor");
    const componentePrincipal = document.querySelector("#conteudo_principal");
    renderizarListaEditoras(componentePrincipal);
  } catch (error) {
    console.error("Erro ao excluir o autor:", error);
  }
}

/**
 * Busca um autor específica para atualização, com base no ID.
 * Após encontrar o autor, renderiza o formulário de atualização.
 * @param {string} id_editora - ID do autor a ser buscada.
 */
async function buscarEditoras(id_editora) {
  try {
    const response = await fetch(`${API_BASE_URL}/editoras/${id_editora}`);
    const editorasBD = await response.json();
    if (editorasBD.length <= 0) return;

    const editoras = editorasBD.map(row => ({
      id_editora: row.id_editora,
      nome_editora: row.nome_editora,
    }))[0];

    const componentePrincipal = document.querySelector("#conteudo_principal");
    componentePrincipal.innerHTML = EditorasView.renderizarFormularioAtualizar(editoras);
    document.getElementById("formulario_editoras_atualizar").addEventListener("submit", atualizarEditoras);
  } catch (error) {
    console.error("Erro ao buscar autores:", error);
  }
}

/**
 * Atualiza um autor específico.
 * A função é acionada pelo evento de submit do formulário de atualização.
 * @param {Event} event - O evento de submit do formulário.
 */
async function atualizarEditoras(event) {
  event.preventDefault();

  const id_editoraValor = document.getElementById("editoras_id_editora_formulario").value;
  const nome_editoraValor = document.getElementById("editoras_nome_editora_formulario").value;
  const editoras = {id_editora: id_editoraValor, nome_editora: nome_editoraValor};

  try {
    const response = await fetch(`${API_BASE_URL}/editoras`, {
      method: "PUT",
      headers: {"Content-Type": "application/json",},
      body: JSON.stringify(editoras),
    });

    if (!response.ok) {
      throw new Error("Falha ao atualizar o autor");
    }
    const componentePrincipal = document.querySelector("#conteudo_principal");
    renderizarListaEditoras(componentePrincipal);
  } catch (error) {
    console.error("Erro ao atualizar o autor:", error);
  }
}

const EditorasController = {
  renderizarEditorasFormulario,
  cadastrarEditoras,
  renderizarListaEditoras,
  excluirEditoras,
};

export default EditorasController;