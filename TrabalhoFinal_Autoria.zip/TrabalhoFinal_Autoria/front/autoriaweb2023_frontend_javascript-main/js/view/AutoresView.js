/**
 * Renderiza o formulário para criar uma nova tarefa.
 * @return {string} HTML do formulário de criação de tarefa.
 */
function renderizarFormulario() {
  return `
          <form class="mt-3" id="formulario_autores">
              <div class="form-group">
                  <label for="autores_nome_autor">nome do autor:</label>
                  <input type="text" class="form-control" id="autores_nome_autor_formulario">
              </div>
              <div class="form-group">
                  <label for="autores_data_nascimento">data de nascimento:</label>
                  <input type="date" class="form-control" id="autores_data_nascimento_formulario">
              </div>
              <button type="submit" class="btn btn-primary mt-2">Salvar</button>
          </form>
      `;
  }
  
  /**
   * Renderiza o formulário para atualizar uma tarefa existente.
   * @param {Object} autores - A tarefa a ser atualizada.
   * @return {string} HTML do formulário de atualização de tarefa.
   */
  function renderizarFormularioAtualizar(autores) {
      return `
              <form class="mt-3" id="formulario_autores_atualizar">
                  <input type="hidden" class="form-control" id="autores_id_autor_formulario" value="${autores.id_autor}">
                  <div class="form-group">
                      <label for="autores_nome_autor">nome do autor:</label>
                      <input type="text" class="form-control" id="autores_nome_autor_formulario" value="${autores.nome_autor}">
                  </div>
                  <div class="form-group">
                      <label for="autores_data_nascimento">data de nascimento:</label>
                      <input type="date" class="form-control" id="autores_data_nascimento_formulario">${autores.data_nascimento}>
                  </div>
                  <button type="submit" class="btn btn-primary mt-2">Salvar</button>
              </form>
          `;
  }
  
  /**
   * Renderiza a tabela de tarefas.
   * @param {Array} autores - Lista de tarefas a serem exibidas.
   * @return {string} HTML da tabela de tarefas.
   */
  function renderizarTabela(autores) {
      let tabela = `
        <table class="table table-striped mt-3">
          <thead>
            <tr>
              <th>Nome do autor</th>
              <th>Data de nascimento</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody>
      `;
    
      autores.forEach((autores) => {
        tabela += `
          <tr>
            <td>${autores.nome_autor}</td>
            <td>${autores.data_nascimento}</td>
            <td>
              <button class="excluir-btn" autores-id_autor="${autores.id_autor}">Excluir</button>
              <button class="atualizar-btn" autores-atualizar-id_autor="${autores.id_autor}">Atualizar</button>
            </td>
          </tr>
        `;
      });
    
      tabela += `
          </tbody>
        </table>
      `;
    
      return tabela;
  }
  
  
  const AutoresView = {
      renderizarFormulario,
      renderizarTabela,
      renderizarFormularioAtualizar
  };
  
  export default AutoresView;