/**
 * Renderiza o formulário para criar uma nova tarefa.
 * @return {string} HTML do formulário de criação de tarefa.
 */
function renderizarFormulario() {
    return `
            <form class="mt-3" id="formulario_books">
                <div class="form-group">
                    <label for="books_nome_book">nome do livro:</label>
                    <input type="text" class="form-control" id="books_nome_book_formulario">
                </div>
                <div class="form-group">
                    <label for="books_escritor_book">escritor:</label>
                    <input type="text" class="form-control" id="books_escritor_book_formulario">
                </div>
                <div class="form-group">
                    <label for="books_editora_book">editora:</label>
                    <input type="text" class="form-control" id="books_editora_book_formulario">
                </div>
                <button type="submit" class="btn btn-primary mt-2">Salvar</button>
            </form>
        `;
    }
    
    /**
     * Renderiza o formulário para atualizar uma tarefa existente.
     * @param {Object} books - A tarefa a ser atualizada.
     * @return {string} HTML do formulário de atualização de tarefa.
     */
    function renderizarFormularioAtualizar(books) {
        return `
                <form class="mt-3" id="formulario_books_atualizar">
                    <input type="hidden" class="form-control" id="books_id_book_formulario" value="${books.id_book}">
                    <div class="form-group">
                        <label for="books_nome_book">nome do livro:</label>
                        <input type="text" class="form-control" id="books_nome_book_formulario" value="${books.nome_book}">
                    </div>
                    <div class="form-group">
                        <label for="books_escritor_book">escritor:</label>
                        <input type="text" class="form-control" id="books_escritor_book_formulario" value="${books.escritor_book}">
                    </div>
                    <div class="form-group">
                        <label for="books_editora_book">editora:</label>
                        <input type="text" class="form-control" id="books_editora_book_formulario" value="${books.editora_book}">
                    </div>
                    <button type="submit" class="btn btn-primary mt-2">Salvar</button>
                </form>
            `;
    }
    
    /**
     * Renderiza a tabela de tarefas.
     * @param {Array} books - Lista de tarefas a serem exibidas.
     * @return {string} HTML da tabela de tarefas.
     */
    function renderizarTabela(books) {
        let tabela = `
          <table class="table table-striped mt-3">
            <thead>
              <tr>
                <th>Nome do livro</th>
                <th>Escritor</th>
                <th>Editora</th>
                <th>Ações</th>
              </tr>
            </thead>
            <tbody>
        `;
      
        books.forEach((books) => {
          tabela += `
            <tr>
              <td>${books.nome_book}</td>
              <td>${books.escritor_book}</td>
              <td>${books.editora_book}</td>
              <td>
                <button class="excluir-btn" books-id_book="${books.id_book}">Excluir</button>
                <button class="atualizar-btn" books-atualizar-id_book="${books.id_book}">Atualizar</button>
              </td>
            </tr>
          `;
        });
      
        tabela += `
            </tbody>
          </table>
        `;
      
        return tabela;
    }
    
    
    const BooksView = {
        renderizarFormulario,
        renderizarTabela,
        renderizarFormularioAtualizar
    };
    
    export default BooksView;