/**
 * Renderiza o formulário para criar uma nova tarefa.
 * @return {string} HTML do formulário de criação de tarefa.
 */
function renderizarFormulario() {
    return `
            <form class="mt-3" id="formulario_editoras">
                <div class="form-group">
                    <label for="editoras_nome_editora">nome da editora:</label>
                    <input type="text" class="form-control" id="editoras_nome_editora_formulario">
                </div>
                <button type="submit" class="btn btn-primary mt-2">Salvar</button>
            </form>
        `;
    }
    
    /**
     * Renderiza o formulário para atualizar uma tarefa existente.
     * @param {Object} editoras - A tarefa a ser atualizada.
     * @return {string} HTML do formulário de atualização de tarefa.
     */
    function renderizarFormularioAtualizar(editoras) {
        return `
                <form class="mt-3" id="formulario_editoras_atualizar">
                    <input type="hidden" class="form-control" id="editoras_id_editora_formulario" value="${editoras.id_editora}">
                    <div class="form-group">
                        <label for="editoras_nome_editora">nome da editora::</label>
                        <input type="text" class="form-control" id="editoras_nome_editora_formulario" value="${editoras.nome_editora}">
                    </div>
                    <button type="submit" class="btn btn-primary mt-2">Salvar</button>
                </form>
            `;
    }
    
    /**
     * Renderiza a tabela de tarefas.
     * @param {Array} editoras - Lista de tarefas a serem exibidas.
     * @return {string} HTML da tabela de tarefas.
     */
    function renderizarTabela(editoras) {
        let tabela = `
          <table class="table table-striped mt-3">
            <thead>
              <tr>
                <th>Nome da editora</th>
                <th>Ações</th>
              </tr>
            </thead>
            <tbody>
        `;
      
        editoras.forEach((editoras) => {
          tabela += `
            <tr>
              <td>${editoras.nome_editora}</td>
              <td>
                <button class="excluir-btn" editoras-id_editora="${editoras.id_editora}">Excluir</button>
                <button class="atualizar-btn"   editoras-atualizar-id_editora="${editoras.id_editora}">Atualizar</button>
              </td>
            </tr>
          `;
        });
      
        tabela += `
            </tbody>
          </table>
        `;
      
        return tabela;
    }
    
    
    const EditorasView = {
        renderizarFormulario,
        renderizarTabela,
        renderizarFormularioAtualizar
    };
    
    export default EditorasView;